#include <iostream>
#include "chessPiece.h"

chessPiece::chessPiece(bool color)
{
	
}
	
bool chessPiece::getPlayerType() const
{
	
}

chessPiece::~chessPiece()
{
	
}
