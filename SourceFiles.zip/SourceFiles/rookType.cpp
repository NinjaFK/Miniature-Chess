#include "rookType.h"
#include <iostream>

rookType::rookType(bool color)
{ 

}
	
bool rookType::move(char startRow, int startCol, char endRow, 
	int endCol, chessPiece*** board)
{
	
}


rookType::~rookType()
{
	
}
