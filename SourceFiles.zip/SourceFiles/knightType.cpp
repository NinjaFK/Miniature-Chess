#include "knightType.h"
#include <iostream>

knightType::knightType(bool color)
{ 

}
	
bool knightType::move(char startRow, int startCol, char endRow,
 int endCol, chessPiece*** board)
{
	
}


knightType::~knightType()
{
	
}
