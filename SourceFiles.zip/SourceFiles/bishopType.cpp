#include "bishopType.h"
#include <cmath>
#include <iostream>

bishopType::bishopType(bool color)
{

}
	
bool bishopType::move(char startRow, int startCol, char endRow, 
	int endCol, chessPiece*** board)
{
	
}


bishopType::~bishopType()
{
	
}
