#include "queenType.h"
#include <iostream>

queenType::queenType(bool color)
{ 

}
	
bool queenType::move(char startRow, int startCol, char endRow,
 int endCol, chessPiece*** board)
{
	

}

queenType::~queenType()
{
	
}
